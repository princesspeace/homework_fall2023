default settings to produce data.
to produce table, put data into google sheets and clean!
