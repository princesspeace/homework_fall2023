I already edited the default batch size since I didn't know how to pass it in as a flag, so:
For 3.1: I just used the provided command for ant, and hopper
For 3.2: I used the provided command for ant, and I think I just manually modified '--num_agent_train_steps_per_iter' in run_hw1.py
For 4.2: I just used the provided command for ant, and hopper, and manually wrote down the data points for both the std and mean.

